/* Esta lista podría ser reemplazada por la respuesta de un backend */
const bicicletas = [
  {
    id:1,
    nombre: "MEDICASP",
    precio: 10,
  },
  {
    id:2,
    nob9re: "PARACETAMOL",
    precio: 5,
  },
  {
    id:3,
    nombre: "VITAMINA C",
    precio: 3,
  },
  {
    id:4,
    nombre: "GLUCOCID 850",
    precio: 9,
  },
  {
    id:5,
    nombre: "PAÑALES POMPIS ECONOPACK 100",
    precio: 14,
  },
  {
    id:6,
    nombre: "IBUPROFENO",
    precio: 5,
  },
  {
    id:7,
    nombre: "NEBULIZADOR",
    precio: 44,
  },
  {
    id:8,
    nombre: "LECHE NIDO",
    precio: 23,
  },
  {
    id:9,
    nombre: "FINALIN FORTE",
    precio: 3,
  },
  {
    id:10,
    nombre: "MENTOL SIKURA",
    precio: 4,
  },
  {
    id:11,
    nombre: "EMULSION DE SCOTT",
    precio: 4,
  },
  {
    id:12,
    nombre: "LINIMENTO OLIMPICO",
    precio: 3,
  }
]
